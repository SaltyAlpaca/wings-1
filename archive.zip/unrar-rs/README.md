# unrar

<https://github.com/muja/unrar.rs>
